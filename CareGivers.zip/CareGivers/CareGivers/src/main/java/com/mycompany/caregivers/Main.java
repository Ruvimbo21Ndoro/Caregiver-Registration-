/* Main.java
 * This is the main section

 * 8 August 2022
*/
package com.mycompany.caregivers;

public class Main {

       public static void main(String[] args) {

           new CareGiverGUI().setGUI();
    }
    
}
